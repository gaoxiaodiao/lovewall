<?php
return [
'session'                => [
    'prefix'         => 'lovewall',
    'type'           => '',
    'auto_start'     => true,
]
];