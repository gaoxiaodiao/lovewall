<?php
namespace app\lovewall\model;
use think\Model;

class Admin extends Model{
	
}