<?php
namespace app\lovewall\model;
use think\Model;

class Love extends Model{
	//protected $pk = 'id';
	
}



